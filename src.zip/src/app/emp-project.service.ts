import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Project } from './project';

// this service can be available to all components in current module
@Injectable({
  providedIn: 'root'
})
export class EmpProjectService {
  
  serverUrl ="http://localhost:7799"

  // inject HttpClient obj in the service
  constructor( private httpsvc:HttpClient) { }

  fetchEmployeeProject():Observable<Project[]>{
    return this.httpsvc.get<Project[]>(this.serverUrl+"/list")
  }

  addEmployeeProject(empno:number,newProject:Project):Observable<Project>{
    var prjdata ={empno:empno,projectid:newProject.projectid,name:newProject.name,location:newProject.location}

    // data in URL Encoded
    var prjDataURLENC ="empno="+empno+"&projectid="+newProject.projectid+"&name="+newProject.name+"&location="+newProject.location

    var reqopts = {
        headers:new HttpHeaders({"Content-Type":"application/json"})
    }

    return this.httpsvc.post<Project>(this.serverUrl+"/register",prjdata,reqopts)
  }

}

