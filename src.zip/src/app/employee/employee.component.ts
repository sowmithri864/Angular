import { Component, OnInit } from '@angular/core';
import { EmpProjectService } from '../emp-project.service';
import { Project } from '../project';
 
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
   
  empno:number
  name:string
  designation: string
  department: string
  projects: Project[]
  isEditableFlag: boolean
  isProjectFormVisible:boolean
  projectFormErr:string
  lastUpdated:Date

  // inject the EmpProjectService in the Employee Component
  constructor(private empsvc:EmpProjectService) { 
    this.empno=15105
    this.lastUpdated= new Date()
    this.name="Chirala Sowmithri"
    this.designation="Trainee Software Engineer"
    this.department="Development"
    this.projects= [
                  {projectid:1,name:"New Project",location:"UK"},
                  {projectid:3,name:"Mobile App",location:"US"},
                  {projectid:5,name:"Admin App",location:"In"}
                ]
    this.isEditableFlag=false
    this.isProjectFormVisible=false
    this.projectFormErr=""
  }
 
  toggleEditable(){
    this.isEditableFlag=!this.isEditableFlag
  }
 
  deleteProjectAtIndex(index:number){
    this.projects.splice(index,1)
  }
 
  addNewProject(newProject:Project){
 
    if(newProject.projectid<1000 || newProject.projectid>9999)
    {
      this.projectFormErr="Project Id must be of 4 digits"
    }
    else if(newProject.name.length<6)
    {
      this.projectFormErr="Project Name must be atleast 6 characters in length"
    }
    else{
      this.isProjectFormVisible=false
      this.projectFormErr=""
      //this.projects.push(newProject) adding the project details in memory array
      
      // add the project details in the db
      this.empsvc.addEmployeeProject(this.empno,newProject).subscribe(
          response=>{ // Push the updates to the server and get confirmation
              console.log("Employee Project Added")
              console.log(response)
 
              this.empsvc.fetchEmployeeProject().subscribe(
                response=>{//Pull the latest updated project list from the server
                  this.projects = response // fetch and assign the updated list    
                }
              )
          },
          error=>{
            console.log(error)
          }
      )
 
    }
  }
 
  showProjectForm(){
    this.isProjectFormVisible=true
  }
 
  // this method is call once component is loaded /initialzed
  ngOnInit(): void {
    this.empsvc.fetchEmployeeProject().subscribe(
        response=>{
          // assign all projects from API to the component
          this.projects = response
        //  console.log(response)
        },
        error=>{
          console.log(error)
        })
  }
 
}