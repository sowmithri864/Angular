export interface Project {
    projectid:Number
    name:string
    location:string
}
